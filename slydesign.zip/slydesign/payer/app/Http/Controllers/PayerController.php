<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Payer;


class PayerController extends Controller
{
    
public function index()
{
        return view('retour_orange.retourorange');
}

    


public function orangeretour(Request $request)
{
    $orange='Cinetpay';
    $prix = '12000'; //volume de sms
    $pay_token = 'test45454666';
    $status ='slydesign';//Ajouter par moi 
    $numero = '0256895255';
    $amount = $request->amount;//la seule valeur recupérée
    $cpm_designation = $request->cpm_designation;
    
    $paye = new Payer;
        
    $paye->reseau= $orange;
    $paye->volume_sms= $prix;
    $paye->trans= $pay_token;
    $paye->status= $status;
    $paye->numero= $numero;
    $paye->prix= $amount;
    $paye->nom= $cpm_designation;
   
    $paye->save();
    // return view('retour_orange.retourorange',[
    //     'pay_token'=>$pay_token,
    //     'payment'=>$payment,
    //     'orange'=> $orange,
    //     'status'=> $status,
    //     'trans'=> $trans,
    //     'amount'=>$amount,
    //     'numero'=>$numero,
    //     'prix'=>$prix,
    //     'nom'=>$nom,
    //     ]);
      
    return view('welcome');

}

}
